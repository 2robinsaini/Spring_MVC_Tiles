package com.java.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.java.spring.service.RegistrationService;

@Controller
public class BaseController {

	@Autowired
	private RegistrationService registrationService;

	@RequestMapping("/")
	public String defaultHome() {
		String nextView = "home";
		return nextView;
	}

	@RequestMapping("/home")
	public String displayHome() {
		String nextView = "home";
		return nextView;
	}

	@RequestMapping("/application")
	public String application() {
		String nextView = "registration";
		return nextView;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String register(Model model, @RequestParam(value = "firstName") String firstName,
			@RequestParam(value = "lastName") String lastName) {
		String nextView = "successRegistration";
		model.addAttribute("firstName", firstName);
		model.addAttribute("lastName", lastName);

		System.out.println("First Name: " + firstName);
		System.out.println("Last Name: " + lastName);

		String message = registrationService.doRegistration(firstName, lastName);

		System.out.println("Message: " + message);

		model.addAttribute("message", message);
		return nextView;
	}
}
