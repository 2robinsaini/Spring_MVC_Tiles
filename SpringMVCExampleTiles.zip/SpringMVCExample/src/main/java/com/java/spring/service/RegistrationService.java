package com.java.spring.service;

public interface RegistrationService {

	public String doRegistration(String firstName, String lastName);

}
