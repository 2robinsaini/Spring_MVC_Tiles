/**
 * 
 */
package com.java.spring.service;

import org.springframework.stereotype.Service;

/**
 * @author Robin.Kumar
 *
 */

@Service
public class RegistrationServiceImpl implements RegistrationService {

	/**
	 * 
	 */
	public String doRegistration(String firstName, String lastName) {
		String message = (firstName.equals(lastName) ? "Please pass the name properly!"
				: ("successful registration for Mr./Ms. " + lastName + " " + firstName));
		return message;
	}

}
