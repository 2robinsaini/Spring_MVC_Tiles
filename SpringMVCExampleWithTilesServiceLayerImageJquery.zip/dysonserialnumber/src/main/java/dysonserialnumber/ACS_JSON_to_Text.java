package dysonserialnumber;

import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Scanner;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import pojo.Paragraph;
import pojo.ParagraphKS;
import pojo.WordObject;

public class ACS_JSON_to_Text {
	public static DecimalFormat df2 = new DecimalFormat(".##");

	public static void main(String[] args) {
		if (args.length == 1)
			processFiles(args[0]);
	}

	public static void processFiles(String folderPath) {

		File jSonFile = new File(folderPath);

		// Handle for _gen file
		if (jSonFile.isFile() && jSonFile.getAbsolutePath().endsWith(".dat")) {
			redactionLogic(jSonFile.getAbsolutePath());
		}

		// Handle for folder having multiple _gen files
		if (jSonFile.isDirectory()) {
			File[] files = jSonFile.listFiles();
			for (File f : files) {

				if (f.getName().endsWith(".dat")) {
					redactionLogic(f.getAbsolutePath());
				}
			}
		}

	}

	private static void redactionLogic(String absolutePath) {
		File jsonFile = new File(absolutePath);
		String content;

		try {
			content = new Scanner(jsonFile).useDelimiter("\\Z").next();
			ObjectMapper objectMapper = new ObjectMapper();
			objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			Paragraph para = objectMapper.readValue(content, Paragraph.class);
			String fileName = jsonFile.getName().split("\\.")[0] + ".txt";
			File txtFile = new File(jsonFile.getParent() + File.separator + fileName);
			System.out.println(fileName + " Done");
			FileWriter fw = new FileWriter(txtFile);
			StringBuilder sb = new StringBuilder();
			for (WordObject s : para.getWordsList()) {
				sb.append(s.getWord() + " ");
			}

			fw.write(sb.toString().trim());
			fw.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static String getTimeFromSec(long timeInmil) {
		double timeInSec = 0;
		timeInSec = new Integer((int) timeInmil);
		// timeInSec = timeInSec / 100;

		int hours = (int) (timeInSec / 3600);
		int minutes = (int) ((timeInSec % 3600) / 60);
		int seconds = (int) (timeInSec % 60);
		int milliseconds = (int) (timeInmil % 1000);

		String totalTime = hours + ":" + minutes + ":" + seconds;
		return totalTime;
	}

}
