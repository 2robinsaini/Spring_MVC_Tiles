package dysonserialnumber;

public class Basic {

	public static void main(String[] args) {
		String sn = "B8T-US-MFK86218A";

		//sn = sn.replaceAll("-", "");
		
		if(sn.contains("-US-") && sn.indexOf("-US-")>=4){
			sn = sn.substring(sn.indexOf("-US-")-3, sn.length());
		}
		else if(sn.contains("US") && !sn.contains("-US-")  && sn.indexOf("US")>=4){
			sn = sn.substring(sn.indexOf("US")-3, sn.length());
		}
		
		System.out.println(sn.indexOf("-US-"));
		
		System.out.println(sn);
		
	}
}
