package dysonserialnumber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@org.springframework.stereotype.Controller
public class Controller {

	@Autowired
	private SNService sNService;

	@RequestMapping("/home")
	public String hello(Model model) {
		return "welcome";
	}

	@RequestMapping(value = "/sn", method = RequestMethod.POST)
	public String serialNumber(Model model, @RequestParam(required = false, value = "startDate") String startDate) {
		model.addAttribute("date", "Passed Date: " + startDate);

		if (startDate == null) {
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
			return "welcome";
		}

		String[] dateArray = startDate.split("-");
		startDate = Integer.parseInt(dateArray[0]) + "-" + Integer.parseInt(dateArray[1]) + "-"
				+ Integer.parseInt(dateArray[2]);
		
		String value = sNService.checkSerialNumberFromDate(startDate);
		model.addAttribute("value", value);

		return "welcome";
	}

	@RequestMapping(value = "/sn")
	public String serialNumberGET(Model model, @RequestParam(required = false, value = "startDate") String startDate) {
		model.addAttribute("date", "Passed Date: " + startDate);

		if (startDate == null) {
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
			return "welcome";
		}

		if (startDate != null && startDate.trim().equals("")) {
			
			String[] dateArray = startDate.split("-");
			startDate = Integer.parseInt(dateArray[0]) + "-" + Integer.parseInt(dateArray[1]) + "-"
					+ Integer.parseInt(dateArray[2]);
			
			String value = sNService.checkSerialNumberFromDate(startDate);
			model.addAttribute("value", value);
		} else {
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
		}

		return "welcome";
	}

	@RequestMapping(value = "/snByFile", method = RequestMethod.POST)
	public String serialNumberByFileName(Model model, @RequestParam(required = false, value = "date") String date,
			@RequestParam(required = false, value = "fileList") String fileList) {

		

		if (date == null || fileList == null) {
			model.addAttribute("date", "Passed Date: " + date);
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
			return "welcome";
		}

		if (date.trim().equals("") || fileList.trim().equals("")) {
			model.addAttribute("date", "Passed Date: " + "");
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
		} else {
			String[] dateArray = date.split("-");
			date = Integer.parseInt(dateArray[0]) + "-" + Integer.parseInt(dateArray[1]) + "-"
					+ Integer.parseInt(dateArray[2]);
			model.addAttribute("date", "Passed Date: " + date);
			String value = sNService.checkSerialNumberFromFileName(date, fileList);
			model.addAttribute("value", value);
		}

		return "welcome";
	}

	@RequestMapping(value = "/snByFile")
	public String serialNumberByFileNameGET(Model model, @RequestParam(required = false, value = "date") String date,
			@RequestParam(required = false, value = "fileList") String fileList) {

		if (date == null || fileList == null) {
			model.addAttribute("date", "Passed Date: " + "");
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
			return "welcome";
		}

		if ((date.trim().equals("") || fileList.trim().equals(""))) {
			model.addAttribute("date", "Passed Date: " + date);
			String value = "Please pass proper Date and File name:";
			model.addAttribute("value", value);
		} else {
			String[] dateArray = date.split("-");
			date = Integer.parseInt(dateArray[0]) + "-" + Integer.parseInt(dateArray[1]) + "-"
					+ Integer.parseInt(dateArray[2]);
			model.addAttribute("date", "Passed Date: " + date);
			String value = sNService.checkSerialNumberFromFileName(date, fileList);
			model.addAttribute("value", value);
		}

		return "welcome";
	}

	@RequestMapping("/")
	public String home(Model model) {
		model.addAttribute("name", "robin");
		return "welcome";
	}

}
