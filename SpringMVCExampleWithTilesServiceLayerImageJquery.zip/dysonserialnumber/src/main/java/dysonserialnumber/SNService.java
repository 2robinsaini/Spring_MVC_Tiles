package dysonserialnumber;


public interface SNService {

public String checkSerialNumberFromDate(String startDate);

public String checkSerialNumberFromFileName(String date, String fileList);
	
}
