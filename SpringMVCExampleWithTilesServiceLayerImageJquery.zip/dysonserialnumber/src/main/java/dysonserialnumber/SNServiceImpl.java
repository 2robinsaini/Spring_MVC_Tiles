package dysonserialnumber;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.FileDeleteStrategy;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

@Service
public class SNServiceImpl implements SNService, Vars {

	public String checkSerialNumberFromDate(String startDate) {
		List<String> snList = new ArrayList<String>();
		String html = "<br><table border='1' align='center'>";
		File folder = new File(Vars.pathOfmasterFolder + File.separator + startDate + "_DoneFile");
		if (folder.exists()) {
			File tempFolder = new File(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");
			if (!tempFolder.exists()) {
				tempFolder.mkdir();
			}
			else{
				tempFolder.deleteOnExit();
			}

			File[] allFiles = folder.listFiles();
			for (File f : allFiles) {
				try {
					FileUtils.copyFile(f, new File(
							Vars.pathOfmasterFolder + File.separator + "tmp_Folder" + File.separator + f.getName()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			snList = SerialNumberCall.processCalls(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");
			
			System.gc();
			
			File fin = new File(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");

			for (File file : fin.listFiles()) {
			    try {
					FileDeleteStrategy.FORCE.delete(file);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}   
			
			
			
			
			html = html + "<tr> <th>" + "S.N." + "</th>" +   "<th> " + "File Name" + "</th> <th> " + "Serial Number" + "</th> <th>" + "Material Name"
					+ "</th> </tr>";
			int i=0;
			for (String s : snList) {
				String[] dataArray = s.split("==>");
				if (dataArray.length == 3)
					html = html + "<tr> <td> " + ++i + "</td> <td>" + dataArray[0] + "</td> <td> " + dataArray[1] + "</td> <td>" + dataArray[2]
							+ "</td> </tr>";

			}
			html = html + "</table>";
			tempFolder.deleteOnExit();
		}

		return "Serial Number: " + html;
	}

	public String checkSerialNumberFromFileName(String date, String fileList) {

		List<String> snList = new ArrayList<String>();
		String html = "<br><table border='1' align='center'>";
		File folder = new File(Vars.pathOfmasterFolder + File.separator + date + "_DoneFile");
		System.out.println("abs " + folder.getAbsolutePath());
		List<String> listOfFiles = Arrays.asList(fileList.split(","));
		
		if (folder.exists()) {
			File tempFolder = new File(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");
			if (!tempFolder.exists()) {
				tempFolder.mkdir();
			}
			else{
				tempFolder.deleteOnExit();
			}

			//List<File> allFiles = new ArrayList<File>();
			for(String fName : listOfFiles){
				File f = new File(Vars.pathOfmasterFolder + File.separator + date + "_DoneFile"+File.separator+fName.trim()+".dat");
				if(f.exists()){
					//allFiles.add(f);
					try {
						FileUtils.copyFile(f, new File(
								Vars.pathOfmasterFolder + File.separator + "tmp_Folder" + File.separator + f.getName()));
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			
			
		/*	for (File f : allFiles) {
				try {
					FileUtils.copyFile(f, new File(
							Vars.pathOfmasterFolder + File.separator + "tmp_Folder" + File.separator + f.getName()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}*/

			snList = SerialNumberCall.processCalls(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");
			
			System.gc();
			
			File fin = new File(Vars.pathOfmasterFolder + File.separator + "tmp_Folder");

			for (File file : fin.listFiles()) {
			    try {
					FileDeleteStrategy.FORCE.delete(file);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}   
			
			
			
			
			html = html + "<tr> <th>" + "S.N." + "</th>" +   "<th> " + "File Name" + "</th> <th> " + "Serial Number" + "</th> <th>" + "Material Name"
					+ "</th> </tr>";
			int i=0;
			for (String s : snList) {
				String[] dataArray = s.split("==>");
				if (dataArray.length == 3)
					html = html + "<tr> <td> " + ++i + "</td> <td>" + dataArray[0] + "</td> <td> " + dataArray[1] + "</td> <td>" + dataArray[2]
							+ "</td> </tr>";

			}
			html = html + "</table>";
			tempFolder.deleteOnExit();
		}

		return "Serial Number: " + html;
	
	}

}
