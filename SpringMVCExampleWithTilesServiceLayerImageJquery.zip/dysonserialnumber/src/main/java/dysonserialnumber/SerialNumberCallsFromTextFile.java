package dysonserialnumber;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class SerialNumberCallsFromTextFile {

	static int snLimit = 5;
	static String notFoundString = "Material Not Found!";
	static int charLimitForSN = 200;

	public static void main(String[] args) {

		if (args.length == 1) {
			String filePath = args[0]; // "E:\\aetna\\sample\\123.txt";
			processCalls(filePath);
		} else {
			System.out.println("please provide text file path:");
		}

	}

	public static List<String> processCalls(String filePath) {

		// convertDatToText(folderPath);
		List<String> result = new ArrayList<String>();
		try {

			Map<String, List<String>> inpStrMap = getFileNameAndSNStringMap(filePath);

			System.out.println("-------------------------------------------------------");

			Map<String, String> foundSerialNumber = new HashMap<String, String>();

			for (Map.Entry<String, List<String>> sInput : inpStrMap.entrySet()) {

				List<String> list = sInput.getValue();

				for (String s : list) {

					s = preProcess(s);

					String updatedTextString = getSerialNumberTextFromInputText(s);

					String sn = getSNfromAString(updatedTextString);
					sn = (sn.trim().equals("") || sn.length() < snLimit) ? "Not Found" : sn;

					// System.out.println(sInput.getKey() + " Serial Number: " +
					// sn);

					if (sn.contains("-US-")) {
						int indexOfSN = sn.indexOf("-US-");
						if (indexOfSN == 4 && sn.startsWith("A")) {
							sn = sn.substring(1, sn.length());
						}

						// Remove repeated serial number
						if (indexOfSN == 6 && (sn.charAt(0) == sn.charAt(3) && sn.charAt(1) == sn.charAt(4)
								&& sn.charAt(2) == sn.charAt(5))) {
							sn = sn.substring(3, sn.length());
						}

					}

					/*
					 * if (sn.contains("US") && !sn.contains("-US-")) { int
					 * indexOfSN = sn.indexOf("US"); if (indexOfSN == 4 &&
					 * sn.startsWith("A")) { sn = sn.substring(1, sn.length());
					 * }
					 * 
					 * // Remove repeated serial number if (indexOfSN == 6 &&
					 * (sn.charAt(0) == sn.charAt(3) && sn.charAt(1) ==
					 * sn.charAt(4) && sn.charAt(2) == sn.charAt(5))) { sn =
					 * sn.substring(3, sn.length()); }
					 * 
					 * }
					 */

					/*
					 * //check if more than 3 leeter before -US-
					 * if(sn.contains("-US-") && sn.indexOf("-US-")>5){ sn =
					 * sn.substring(sn.indexOf("-US-")-5, sn.length()); }
					 * //check if more than 3 leeter before US else
					 * if(sn.contains("US") && sn.indexOf("US")>4){ sn =
					 * sn.substring(sn.indexOf("US")-4, sn.length()); }
					 */

					if (sn.contains("-US-") && sn.indexOf("-US-") >= 4) {
						sn = sn.substring(sn.indexOf("-US-") - 3, sn.length());
					} else if (sn.contains("US") && !sn.contains("-US-") && sn.indexOf("US") >= 4) {
						sn = sn.substring(sn.indexOf("US") - 3, sn.length());
					}

					String snMatched = sInput.getKey();

					if (foundSerialNumber.containsKey(snMatched)) {
						String oldSN = foundSerialNumber.get(snMatched).trim();

						if (oldSN.equals("Not Found") && !sn.trim().equals("Not Found")) {
							foundSerialNumber.put(snMatched, sn);
						} else if (!oldSN.equals("Not Found") && sn.length() <= oldSN.length()) {
							foundSerialNumber.put(snMatched, oldSN);
						} else if (!oldSN.equals("Not Found") && !sn.trim().equals("Not Found")
								&& sn.length() > oldSN.length()) {
							foundSerialNumber.put(snMatched, sn);
						}

					} else {
						foundSerialNumber.put(snMatched, sn);
					}

				}

			}

			Map<String, String> mapSNMaterial = BasicOps.getMaterialSNMap();

			Map<String, String> mapMaterialMaterialDesc = BasicOps.getMaterialDescMap1();
			Map<String, String> mapMaterialMaterialDesc2 = BasicOps.getMaterialDescMap2();
			Map<String, String> mapMaterialMaterialDesc3 = BasicOps.getMaterialDescMap3();
			mapMaterialMaterialDesc.putAll(mapMaterialMaterialDesc2);
			mapMaterialMaterialDesc.putAll(mapMaterialMaterialDesc3);

			String sn = null;
			File tmpFile = new File(filePath);
			FileWriter fw = new FileWriter(
					new File((tmpFile).getParent() + File.separator + tmpFile.getName().replaceAll(".txt", "_") + "SerialNumber_results.csv"));
			for (Map.Entry<String, String> ent : foundSerialNumber.entrySet()) {

				sn = ent.getValue();

				if (sn.equals("Not Found")) {
					System.out.println(ent.getKey() + " ==> " + ent.getValue());
				} else {

					if (sn.contains("-")) {
						sn = sn.replaceAll("-", "");
					}
					if (sn.length() >= snLimit) {
						String productMaterial = mapMaterialMaterialDesc
								.get(mapSNMaterial.get(sn.substring(0, snLimit)));
						String updatedNFS = (mapSNMaterial.containsKey(sn.substring(0, snLimit)))
								? notFoundString + " (But Serial Number matched!)" : notFoundString;

						productMaterial = (productMaterial == null) ? updatedNFS : productMaterial;
						fw.write(ent.getKey() + "," + ent.getValue() + "," + productMaterial+"\n");
						System.out.println(ent.getKey() + " ==> " + ent.getValue() + " ==> " + productMaterial);
						result.add(ent.getKey() + " ==> " + ent.getValue() + " ==> " + productMaterial);

					}

				}
			}
			fw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	private static void convertDatToText(String folderPath) {
		ACS_JSON_to_Text.processFiles(folderPath);
	}

	private static String preProcess(String s) {

		s = s.replaceAll(" for ", " four ");
		s = s.replaceAll(" be ", " b ");
		s = s.replaceAll(" we ", " v ");
		s = s.replaceAll(" are ", " r ");
		s = s.replaceAll(" see ", " c ");
		s = s.replaceAll(" sea ", " c ");
		s = s.replaceAll(" queue ", " q ");
		s = s.replaceAll(" to ", " two ");
		s = s.replaceAll(" too ", " two ");
		// s = s.replaceAll(" an ", " n ");

		s = s.replaceAll(" then number ", " ");
		s = s.replaceAll(" then ", " ");
		s = s.replaceAll(" number ", " ");
		s = s.replaceAll(" and then ", " ");
		s = s.replaceAll(" us like united states ", " U S ");
		s = s.replaceAll(" why ", " Y ");
		s = s.replaceAll(" like ", " as in ");

		return s;
	}

	/**
	 * 
	 * @param updatedTextString
	 * @return Serial Number extracted from the input string
	 */
	private static String getSNfromAString(String updatedTextString) {

		List<String> wordListOfInput = Arrays
				.asList(updatedTextString.replaceAll("   ", " ").replaceAll("  ", " ").trim().split(" "));
		List<String> numCharList = getNumberCharList();
		String snString = "";
		boolean isSNinProgress = false;
		boolean isSNFound = false;
		int count = 0;
		for (int i = 0; i < wordListOfInput.size(); i++) {
			if (i > 1 && isSNinProgress && numCharList.contains(wordListOfInput.get(i))
					&& numCharList.contains(wordListOfInput.get(i - 1))) {
				if (count == 0) {
					snString = snString + (wordListOfInput.get(i - 1)) + (wordListOfInput.get(i));
					count++;
				} else {
					snString = snString + (wordListOfInput.get(i));
					isSNFound = true;
				}
			}
			if (numCharList.contains(wordListOfInput.get(i))) {
				isSNinProgress = true;
			}
			if (isSNinProgress && !numCharList.contains(wordListOfInput.get(i))) {
				isSNinProgress = false;
				count = 0;

				if (snString.length() < snLimit) {
					snString = "";
				}

				if (isSNFound && !snString.trim().equals("")) {
					break;
				}

			}
		}

		snString = postProcessUF2US(snString);

		return snString; // .replace("US", "-US-").replaceAll("--", "-");
	}

	private static String postProcessUF2US(String snString) {
		// System.out.println(snString);
		/*
		 * if (snString.length() >= 5) { if (snString.charAt(3) == 'U' &&
		 * snString.charAt(4) == 'F') { snString = snString.substring(0, 4) +
		 * "S" + snString.substring(5, snString.length()); } } if
		 * (snString.length() > 5 && snString.contains("-")) { if
		 * (snString.charAt(4) == 'U' && snString.charAt(5) == 'F') { snString =
		 * snString.substring(0, 5) + "S" + snString.substring(6,
		 * snString.length()); } }
		 */

		snString = snString.replaceAll("-UF-", "-US-").replaceAll("UF", "US");
		return snString;
	}

	private static String getSerialNumberTextFromInputText(String sInput) {

		String inputTextString = sInput;

		Map<String, String> mapOfStrToNum = getMapStringToNumber();
		String updatedTextString = updateFor_AS_IN(inputTextString);
		updatedTextString = updateString(updatedTextString, mapOfStrToNum);
		updatedTextString = putProperDashes(updatedTextString, "dash");

		/*
		 * if (!updatedTextString.contains("-")) { updatedTextString =
		 * putProperDashes(updatedTextString); }
		 */

		return updatedTextString;
	}

	private static Map<String, List<String>> getFileNameAndSNStringMap(String folderPath) {
		Map<String, List<String>> map = new HashMap<String, List<String>>();

		File f = new File(folderPath);
		// File[] files = folder.listFiles();
		// for (File f : files) {
		if (f.isFile() && f.getName().endsWith(".txt")) {
			try {
				String fileContent = getCompleteContentOfFile(f);

				fileContent = fileContent.replace("\n", " ").replaceAll("Client:", " ").replaceAll("Agent:", " ")
						.replaceAll("  ", " ");

				String serialNumberString = "Not found";

				// int indexOfSerialNumber = fileContent.indexOf("serial
				// number");
				List<Integer> index = findWord(fileContent, "serial number");

				if (index.size() > 0) {
					for (Integer indexOfSerialNumber : index) {
						if (indexOfSerialNumber > -1 && fileContent.length() > indexOfSerialNumber + charLimitForSN) {
							serialNumberString = fileContent.substring(indexOfSerialNumber,
									indexOfSerialNumber + charLimitForSN);

							if (map.containsKey(f.getName())) {

								List<String> snContent = new ArrayList<String>();
								snContent = map.get(f.getName());
								snContent.add(serialNumberString);

								map.put(f.getName(), snContent);
							} else {
								List<String> snContent = new ArrayList<String>();
								snContent.add(serialNumberString);
								map.put(f.getName(), snContent);
							}

						} else if (indexOfSerialNumber > -1) {
							serialNumberString = fileContent.substring(indexOfSerialNumber, fileContent.length());
							if (map.containsKey(f.getName())) {
								List<String> snContent = new ArrayList<String>();
								snContent = map.get(f.getName());
								snContent.add(serialNumberString);
								map.put(f.getName(), snContent);
							} else {
								List<String> snContent = new ArrayList<String>();
								snContent.add(serialNumberString);
								map.put(f.getName(), snContent);
							}
						} else {
							serialNumberString = "Not Found";
						}

						// System.out.println("Serial Number in " + f.getName()
						// + " ==> " + serialNumberString);
					}
				}

				else {
					// System.out.println("Serial Number in " + f.getName() + "
					// ==> " + serialNumberString);
				}

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		// }

		return map;
	}

	private static List<Integer> findWord(String textString, String word) {
		List<Integer> indexes = new ArrayList<Integer>();
		String lowerCaseTextString = textString.toLowerCase();
		String lowerCaseWord = word.toLowerCase();

		int index = 0;
		while (index != -1) {
			index = lowerCaseTextString.indexOf(lowerCaseWord, index);
			if (index != -1) {
				indexes.add(index);
				index++;
			}
		}
		return indexes;
	}

	private static String getCompleteContentOfFile(File f) throws FileNotFoundException {
		StringBuilder sb = new StringBuilder();
		Scanner sc = new Scanner(f);
		while (sc.hasNext()) {
			sb.append(sc.nextLine());
		}
		return sb.toString();
	}

	private static String updateFor_AS_IN(String inputTextString) {

		List<String> wordListOfInput = Arrays
				.asList(inputTextString.trim().replaceAll("   ", " ").replaceAll("  ", " ").split(" "));

		for (int i = 0; i < wordListOfInput.size(); i++) {

			if (i > 0 && i < wordListOfInput.size() - 2
					&& (wordListOfInput.get(i).equalsIgnoreCase("as") || wordListOfInput.get(i).equalsIgnoreCase("is"))
					&& (wordListOfInput.get(i + 1).equalsIgnoreCase("in")
							|| wordListOfInput.get(i + 1).equalsIgnoreCase("an"))) {

				String matchString = "";
				if (wordListOfInput.get(i - 1).length() == 1) {
					matchString = wordListOfInput.get(i - 1) + " " + wordListOfInput.get(i) + " "
							+ wordListOfInput.get(i + 1) + " " + wordListOfInput.get(i + 2);
				} else {
					matchString = wordListOfInput.get(i) + " " + wordListOfInput.get(i + 1) + " "
							+ wordListOfInput.get(i + 2);
				}

				/*
				 * String matchString = wordListOfInput.get(i - 1) + " " +
				 * wordListOfInput.get(i) + " " + wordListOfInput.get(i + 1) +
				 * " " + wordListOfInput.get(i + 2);
				 */

				String replaceString = wordListOfInput.get(i + 2).substring(0, 1);
				inputTextString = inputTextString.replaceFirst(matchString, replaceString);
			}

		}
		return inputTextString;
	}

	private static String putProperDashes(String updatedTextString, String dashSstring) {
		if (updatedTextString.contains(dashSstring)) {
			updatedTextString = updatedTextString.replaceAll(" " + dashSstring + " ", " - ");
		}
		return updatedTextString;
	}

	private static String putProperDashes(String updatedTextString) {
		List<String> wordListOfInput = Arrays.asList(updatedTextString.trim().split(" "));
		String updatedTextStringResult = "";
		for (int i = 0; i < wordListOfInput.size(); i++) {

			updatedTextStringResult = updatedTextStringResult + wordListOfInput.get(i) + " ";

			if (i == 2) {
				updatedTextStringResult = updatedTextStringResult + "-";
			}
			if (i == 4) {
				updatedTextStringResult = updatedTextStringResult + "-";
			}

		}
		return updatedTextStringResult.trim();
	}

	private static String updateString(String inputTextString, Map<String, String> mapOfStrToNum) {
		List<String> wordListOfInput = Arrays.asList(inputTextString.trim().split(" "));
		List<String> wordListOfInput2 = new ArrayList<String>();
		for (String word : wordListOfInput) {
			if (word.length() == 1) {
				wordListOfInput2.add(word.toUpperCase());
			} else {
				if (mapOfStrToNum.containsKey(word)) {
					wordListOfInput2.add(mapOfStrToNum.get(word));
				} else {
					wordListOfInput2.add(word);
				}
			}
		}
		inputTextString = "";
		for (String s : wordListOfInput2) {
			inputTextString = inputTextString + s + " ";
		}
		return inputTextString.trim();
	}

	private static Map<String, String> getMapStringToNumber() {
		Map<String, String> mapOfStrToNum = new HashMap<String, String>();
		mapOfStrToNum.put("zero", "0");
		mapOfStrToNum.put("one", "1");
		mapOfStrToNum.put("two", "2");
		mapOfStrToNum.put("three", "3");
		mapOfStrToNum.put("four", "4");
		mapOfStrToNum.put("five", "5");
		mapOfStrToNum.put("six", "6");
		mapOfStrToNum.put("seven", "7");
		mapOfStrToNum.put("eight", "8");
		mapOfStrToNum.put("nine", "9");
		return mapOfStrToNum;
	}

	private static List<String> getNumberCharList() {
		List<String> list = new ArrayList<String>();
		list.add("-");
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		list.add("E");
		list.add("F");
		list.add("G");
		list.add("H");
		list.add("I");
		list.add("J");
		list.add("K");
		list.add("L");
		list.add("M");
		list.add("N");
		list.add("O");
		list.add("P");
		list.add("Q");
		list.add("R");
		list.add("S");
		list.add("T");
		list.add("U");
		list.add("V");
		list.add("W");
		list.add("X");
		list.add("Y");
		list.add("Z");
		list.add("0");
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		list.add("5");
		list.add("6");
		list.add("7");
		list.add("8");
		list.add("9");
		return list;
	}

	public static List<String> getListOFCountryCode() {
		List<String> countryCodeList = new ArrayList<String>();
		countryCodeList.add("AU");
		countryCodeList.add("BR");
		countryCodeList.add("CA");
		countryCodeList.add("CH");
		countryCodeList.add("CN");
		countryCodeList.add("CO");
		countryCodeList.add("EU");
		countryCodeList.add("HK");
		countryCodeList.add("ID");
		countryCodeList.add("IE");
		countryCodeList.add("IL");
		countryCodeList.add("IN");
		countryCodeList.add("JP");
		countryCodeList.add("KR");
		countryCodeList.add("MX");
		countryCodeList.add("MY");
		countryCodeList.add("PH");
		countryCodeList.add("RU");
		countryCodeList.add("SA");
		countryCodeList.add("SG");
		countryCodeList.add("TH");
		countryCodeList.add("TR");
		countryCodeList.add("TW");
		countryCodeList.add("UK");
		countryCodeList.add("US");
		countryCodeList.add("XB");
		countryCodeList.add("XC");
		countryCodeList.add("XD");
		countryCodeList.add("XE");
		countryCodeList.add("XF");
		countryCodeList.add("XG");
		countryCodeList.add("XH");
		countryCodeList.add("ZC");

		return countryCodeList;
	}

}
