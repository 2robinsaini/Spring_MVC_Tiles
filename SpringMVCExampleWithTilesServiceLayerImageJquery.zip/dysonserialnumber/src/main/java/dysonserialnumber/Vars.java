package dysonserialnumber;

public interface Vars {

	//public static final String pathOfmasterFolder = "E:/DYSON/serial_number/dyson_calls";
	public static final String pathOfmasterFolder = "/mount/dyson/WIN_SHARE/WIN_JSON";
	
}
