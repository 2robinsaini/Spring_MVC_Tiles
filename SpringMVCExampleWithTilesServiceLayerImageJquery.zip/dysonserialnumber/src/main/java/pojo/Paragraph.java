package pojo;

import java.text.DecimalFormat;
import java.util.List;

/**
 * 
 * @author Robin.Kumar
 *
 */
public class Paragraph {

	private String fileName;
	private double callDuration;
	private double nonTalkTime;
	private List<String> beepDuration;
	private List<WordObject> wordsList;
	private String lob;
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public double getCallDuration() {
		return callDuration;
	}
	public void setCallDuration(double callDuration) {
		DecimalFormat df = new DecimalFormat("#.##");
		this.callDuration = Double.parseDouble(df.format(callDuration));
	}
	
	public double getNonTalkTime() {
		return nonTalkTime;
	}
	public void setNonTalkTime(double nonTalkTime) {
		DecimalFormat df = new DecimalFormat("#.##");
		this.nonTalkTime = Double.parseDouble(df.format(nonTalkTime));
	}
	public List<String> getBeepDuration() {
		return beepDuration;
	}
	public void setBeepDuration(List<String> beepDuration) {
		this.beepDuration = beepDuration;
	}
	public List<WordObject> getWordsList() {
		return wordsList;
	}
	public void setWordsList(List<WordObject> wordsList) {
		this.wordsList = wordsList;
	}
	public Paragraph() {
		
	}
	public String getLob() {
		return lob;
	}
	public void setLob(String lob) {
		this.lob = lob;
	}
	
	
}
