package pojo;

import java.io.Serializable;
import java.util.List;

public class ParagraphKS implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String transcript;
	private double callDuration;
	private List<Words> words;
	
	public String getTranscript() {
		return transcript;
	}
	public void setTranscript(String transcript) {
		this.transcript = transcript;
	}
	
	public double getCallDuration() {
		return callDuration;
	}
	public void setCallDuration(double callDuration) {
		this.callDuration = callDuration;
	}
	public List<Words> getWords() {
		return words;
	}
	public void setWords(List<Words> words) {
		this.words = words;
	}

	
}
