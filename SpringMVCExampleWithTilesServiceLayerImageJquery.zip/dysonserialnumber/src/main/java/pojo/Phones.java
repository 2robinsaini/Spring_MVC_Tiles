package pojo;

import java.io.Serializable;

public class Phones implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private double duration;
	private String phone;
	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	

}
