package pojo;

import java.text.DecimalFormat;

/**
 * 
 * @author Robin.Kumar
 *
 */
public class WordObject {

	private String word;
	private double start;
	private double end;
	private String speakerType;
	private String gender;
	private double confidence;
	private double score;

	public WordObject(String word, double start, double end, String speakerType, String gender, double confidence,
			double score) {
		super();
		DecimalFormat df = new DecimalFormat("#.##");      
		
		this.word = word;
		//this.start = start;
		this.start = Double.valueOf(df.format(start));
		//System.out.println("End1 " + end);
		this.end = Double.valueOf(df.format(end));
		//System.out.println("End2 " + this.end);
		this.speakerType = speakerType;
		this.gender = gender;
		this.confidence = confidence;
		this.score = score;
	}

	
	
	
	public WordObject() {
		super();
	}




	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public double getStart() {
		return start;
	}

	public void setStart(double start) {
		this.start = start;
	}

	public double getEnd() {
		return end;
	}

	public void setEnd(double end) {
		this.end = end;
	}

	public String getSpeakerType() {
		return speakerType;
	}

	public void setSpeakerType(String speakerType) {
		this.speakerType = speakerType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getConfidence() {
		return confidence;
	}

	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	
}
