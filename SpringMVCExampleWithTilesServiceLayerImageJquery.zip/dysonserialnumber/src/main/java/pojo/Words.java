package pojo;

import java.io.Serializable;
import java.util.List;


public class Words implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String alignedWord;
	private String cases;
	private double end;
	private double endOffset;
	private List<Phones> phones;
	private double start;
	private double startOffset;
	private String word;
	public String getAlignedWord() {
		return alignedWord;
	}
	public void setAlignedWord(String alignedWord) {
		this.alignedWord = alignedWord;
	}
	public String getCases() {
		return cases;
	}
	public void setCases(String cases) {
		this.cases = cases;
	}
	public double getEnd() {
		return end;
	}
	public void setEnd(double end) {
		this.end = end;
	}
	public double getEndOffset() {
		return endOffset;
	}
	public void setEndOffset(double endOffset) {
		this.endOffset = endOffset;
	}
	
	public List<Phones> getPhones() {
		return phones;
	}
	public void setPhones(List<Phones> phones) {
		this.phones = phones;
	}
	public double getStart() {
		return start;
	}
	public void setStart(double start) {
		this.start = start;
	}
	public double getStartOffset() {
		return startOffset;
	}
	public void setStartOffset(double startOffset) {
		this.startOffset = startOffset;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		Words wd = new Words();
		wd.alignedWord = this.alignedWord;
		wd.cases = this.cases;
		wd.end = this.end;
		wd.endOffset = this.endOffset;
		wd.phones = this.phones;
		wd.start = this.start;
		wd.word = this.word;
		return wd;
	}
	
	



}
